<?php

$dbhostname = 'zainulbr.pe.hu';
$dbusername = 'u839751986_mate';
$dbpassword = 'qwerty';
$dbname = 'materialize';

$mysqli = new mysqli($dbhostname, $dbusername, $dbpassword, $dbname);

if($mysqli->connect_error){
	die('database connection error');
}